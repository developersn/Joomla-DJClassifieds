<?php
@session_start();
defined('_JEXEC') or die('Restricted access');
jimport('joomla.event.plugin');
$lang = JFactory::getLanguage();
$lang->load('plg_djclassifiedspayment_djcfsn',JPATH_ADMINISTRATOR);
class plgdjclassifiedspaymentdjcfsn extends JPlugin
{
	function plgdjclassifiedspaymentdjcfsn( &$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage('plg_djcfsn');
		$params["plugin_name"] = "djcfsn";
		$params["icon"] = "sn_icon.png";
		$params["logo"] = "sn_overview.png";
		$params["description"] = 'DJ Classifieds sn payment';
		$params["payment_method"] = 'sn';
		$params["api"] = $this->params->get("api");
		$this->params = $params;
	}
	function onProcessPayment()
	{
		$ptype = JRequest::getVar('ptype','');
		$id = JRequest::getInt('id','0');
		$html="";

			
		if($ptype == $this->params["plugin_name"])
		{
			$action = JRequest::getVar('pactiontype','');
			switch ($action)
			{
				case "process" :
				$html = $this->process($id);
				break;
				case "notify" :
				$html = $this->_notify_url();
				break;
				case "paymentmessage" :
				$html = $this->_paymentsuccess();
				break;
				default :
				$html =  $this->process($id);
				break;
			}
		}
		return $html;
	}
	function _notify_url()
	{
		$db = JFactory::getDBO();
		$par = &JComponentHelper::getParams( 'com_djclassifieds' );
		$user	= JFactory::getUser();
		$id	= JRequest::getInt('id','0');
	// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security
		header('Content-Type: text/html; charset=utf-8');
	$transData = $_SESSION[$sec];
    $au = $transData['au'];
    $orderID = $_GET["orderid"];
	$amount = $_GET["price"];
if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl )
{
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $this->params['api'],
'price' => $amount,
'order_id' => $orderID,
'au' => $au,
'bank_return' =>$bank_return,
));


$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);
		
		
		if($json['result'] == 1)
		{
			$query = "SELECT p.*  FROM #__djcf_payments p WHERE p.id='".$id."' ";
			$db->setQuery($query);
			$payment = $db->loadObject();
			
			if($payment)
			{
				$query = "UPDATE #__djcf_payments SET status='Completed',transaction_id='".$au."' WHERE id=".$id." AND method='djcfsn'";					
				$db->setQuery($query);
				$db->query();

				if($payment->type==2)
				{
					$date_sort = date("Y-m-d H:i:s");
					$query = "UPDATE #__djcf_items SET date_sort='".$date_sort."' WHERE id=".$payment->item_id." ";
					$db->setQuery($query);
					$db->query();
				}
				else if($payment->type==1)
				{
					$query = "SELECT p.points  FROM #__djcf_points p WHERE p.id='".$payment->item_id."' ";					
					$db->setQuery($query);
					$points = $db->loadResult();
					$query = "INSERT INTO #__djcf_users_points (`user_id`,`points`,`description`) VALUES ('".$payment->user_id."','".$points."','".JText::_('COM_DJCLASSIFIEDS_POINTS_PACKAGE')." sn <br />".JText::_('COM_DJCLASSIFIEDS_PAYMENT_ID').' '.$payment->id."')";					
					$db->setQuery($query);
					$db->query();																		
				}
				else
				{
					$query = "SELECT c.*  FROM #__djcf_items i, #__djcf_categories c WHERE i.cat_id=c.id AND i.id='".$payment->item_id."' ";					
					$db->setQuery($query);
					$cat = $db->loadObject();
					$pub=0;
					if(($cat->autopublish=='1') || ($cat->autopublish=='0' && $par->get('autopublish')=='1'))
					{
						$pub = 1;							 						
					}
					$query = "UPDATE #__djcf_items SET payed=1, pay_type='', published='".$pub."' WHERE id=".$payment->item_id." ";					
					$db->setQuery($query);
					$db->query();			
				}
				exit('<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">پرداخت با موفقیت ثبت شد.<br />شماره پیگیری : '.$au.'.<br /><a href="./?">برای ادامه کلیک کنید</a></p>');
			}
			else
			{
				exit('<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">سفارش شما معتبر نیست. این خطا به مدیریت سای اطلاع دهید.<br />شماره پیگیری : '.$au.'.<br /><a href="./?">برای ادامه کلیک کنید</a></p>');
			}
		}
		else
		{
			$err = 'خطای غیر منتظره!!!';
			$query = "UPDATE #__djcf_payments SET status='err',transaction_id='".$au."' WHERE id=".$id." AND method='djcfsn'";					
			$db->setQuery($query);
			$db->query();	
			exit('<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">'.$err.'<br /><a href="./?">برای ادامه کلیک کنید</a></p>');
		}
		else
		{
			$err = 'خطای غیر منتظره!!!';
			$query = "UPDATE #__djcf_payments SET status='err',transaction_id='".$au."' WHERE id=".$id." AND method='djcfsn'";					
			$db->setQuery($query);
			$db->query();	
			exit('<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">'.$err.'<br /><a href="./?">برای ادامه کلیک کنید</a></p>');
		}
	}
	
	function process($id)
	{
		JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'tables');		
		jimport( 'joomla.database.table' );
		$db 	= JFactory::getDBO();
		$app 	= JFactory::getApplication();
		$Itemid = JRequest::getInt("Itemid",'0');
		$par 	= JComponentHelper::getParams( 'com_djclassifieds' );
		$user 	= JFactory::getUser();
		$ptype	= JRequest::getVar('ptype');
		$type	= JRequest::getVar('type','');
		$row 	= JTable::getInstance('Payments', 'DJClassifiedsTable');	

		 if($type=='prom_top'){        	        	
        	$query ="SELECT i.* FROM #__djcf_items i "
        			."WHERE i.id=".$id." LIMIT 1";
        	$db->setQuery($query);
        	$item = $db->loadObject();
        	if(!isset($item)){
        		$message = JText::_('COM_DJCLASSIFIEDS_WRONG_AD');
        		$redirect="index.php?option=com_djclassifieds&view=items&cid=0";
        	}        						 
        					 
       		$row->item_id = $id;
       		$row->user_id = $user->id;
      		$row->method = $ptype;
       		$row->status = 'Start';
      		$row->ip_address = $_SERVER['REMOTE_ADDR'];
       		$row->price = $par->get('promotion_move_top_price',0);
       		$row->type=2;        	
       		$row->store();

       		$amount = $par->get('promotion_move_top_price',0);
      		$itemname = $item->name;
       		$item_id = $row->id;
       		$item_cid = '&cid='.$item->cat_id;       	
        }else if($type=='points'){
			$query ="SELECT p.* FROM #__djcf_points p "				   
				   ."WHERE p.id=".$id." LIMIT 1";
			$db->setQuery($query);
			$points = $db->loadObject();
			if(!isset($item)){
				$message = JText::_('COM_DJCLASSIFIEDS_WRONG_POINTS_PACKAGE');
				$redirect="index.php?option=com_djclassifieds&view=items&cid=0";
			}			
				$row->item_id = $id;
				$row->user_id = $user->id;
				$row->method = $ptype;
				$row->status = 'Start';
				$row->ip_address = $_SERVER['REMOTE_ADDR'];
				$row->price = $points->price; 
				$row->type=1;
				
				$row->store();		
			
			$amount = $points->price;
			$itemname = $points->name;
			$item_id = $row->id;
			$item_cid = '';
		}else{
			$query ="SELECT i.*, c.price as c_price FROM #__djcf_items i "
				   ."LEFT JOIN #__djcf_categories c ON c.id=i.cat_id "
				   ."WHERE i.id=".$id." LIMIT 1";
			$db->setQuery($query);
			$item = $db->loadObject();
			if(!isset($item)){
				$message = JText::_('COM_DJCLASSIFIEDS_WRONG_AD');
				$redirect="index.php?option=com_djclassifieds&view=items&cid=0";
			}
			
				$amount = 0;
				
				if(strstr($item->pay_type, 'cat')){			
					$amount += $item->c_price/100; 
				}
				if(strstr($item->pay_type, 'duration_renew')){			
					$query = "SELECT d.price_renew FROM #__djcf_days d "
					."WHERE d.days=".$item->exp_days;
					$db->setQuery($query);
					$amount += $db->loadResult();
				}else if(strstr($item->pay_type, 'duration')){			
					$query = "SELECT d.price FROM #__djcf_days d "
					."WHERE d.days=".$item->exp_days;
					$db->setQuery($query);
					$amount += $db->loadResult();
				}
				
				$query = "SELECT p.* FROM #__djcf_promotions p "
					."WHERE p.published=1 ORDER BY p.id ";
				$db->setQuery($query);
				$promotions=$db->loadObjectList();
				if ($promotions)
				{
					foreach($promotions as $prom){
						if(strstr($item->pay_type, $prom->name)){	
							$amount += $prom->price; 
						}	
					}
				}
if ($item->special)
{
	$amount += $par->get('prom_price');
}
/*
*/
				$query = 'DELETE FROM #__djcf_payments WHERE item_id= "'.$id.'" ';
				$db->setQuery($query);
				$db->query();
				
				
				$query = 'INSERT INTO #__djcf_payments ( item_id,user_id,method,  status)' .
						' VALUES ( "'.$id.'" ,"'.$user->id.'","'.$ptype.'" ,"Start" )'
						;
				$db->setQuery($query);
				$db->query();

$query = "SELECT max(id) FROM #__djcf_payments";
$db->setQuery($query);
$item_id = $db->loadResult();
/*
					$row->item_id = $id;
					$row->user_id = $user->id;
					$row->method = $ptype;
					$row->status = 'Start';
					$row->ip_address = $_SERVER['REMOTE_ADDR'];
					$row->price = $amount;
					$row->type=0;
				$row->store();
*/
			
		
		
			$itemname = $item->name;
			//$item_id = $row->id;
			$item_cid = '&cid='.$item->cat_id;
		}
		 // Security
$sec = uniqid();
$md = md5($sec.'vm');
// Security

		$redirect = JRoute::_(JURI::root().'index.php?option=com_djclassifieds&task=processPayment&ptype='.$this->params["plugin_name"].'&pactiontype=notify&id='.$item_id.'&Itemid='.$Itemid.'&md='.$md.'&sec='.$sec);
		$orderID  = rand(1,999999999);


$data_string = json_encode(array(
'pin'=> $this->params['api'],
'price'=> $amount,
'callback'=> $redirect,
'order_id'=> $orderID,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
		$html = '<html><head><title></title></head><body><div style="margin: auto; text-align: center;">';
	if(!empty($json['result']) AND $json['result'] == 1)
		{
			$html .= '<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>';
			$html .= '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">در حال اتصال به درگاه ...</p>';
			@session_start();
// Set Session
$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=>$orderID ,
	'au'=>$json['au'] ,
];
		}
		else
		{
			$html .= '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">خطای غیر منتظره ('.$json['msg'].') !!!</p>';
		}
		$html .= '</div></body></html>';
		header('Content-Type: text/html; charset=utf-8');
		echo $html;
		exit;
	}

	function onPaymentMethodList($val)
	{
		$type='';
		if($val['type']){
			$type='&type='.$val['type'];	
		}		
		$html ='';
		if($this->params["api"]!=''){
			$paymentLogoPath = JURI::root()."plugins/djclassifiedspayment/".$this->params["plugin_name"]."/".$this->params["plugin_name"]."/images/".$this->params["logo"];
			$form_action = JRoute :: _("index.php?option=com_djclassifieds&task=processPayment&ptype=".$this->params["plugin_name"]."&pactiontype=process&id=".$val["id"].$type, false);
			$html ='<table cellpadding="5" cellspacing="0" width="100%" border="0">
				<tr>';
					if($this->params["logo"] != ""){
				$html .='<td class="td1" width="160" align="center">
						<img src="'.$paymentLogoPath.'" title="'. $this->params["payment_method"].'"/>
					</td>';
					 }
					$html .='<td class="td2">
						<h2>SAMAN BANK</h2>
						<p style="text-align:justify;">'.$this->params["description"].'</p>
					</td>
					<td class="td3" width="130" align="center">
						<a class="button" style="text-decoration:none;" href="'.$form_action.'">پرداخت</a>
					</td>
				</tr>
			</table>';
		}
		return $html;
	}
}
?>