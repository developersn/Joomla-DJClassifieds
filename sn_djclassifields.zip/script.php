<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgDjclassifiedspaymentDjcfsn_djclassifieldsInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_djclassifieds'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه دی جی کلاس فیلدز را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'djcfsn_djclassifields'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'djclassifiedspayment' .DS. 'djcfsn_djclassifields' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);

        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }
    }

    function uninstall($parent)
    {

    }
}