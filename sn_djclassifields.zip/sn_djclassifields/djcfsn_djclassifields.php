<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.event.plugin');
jimport('sncore.include');

class plgDjclassifiedspaymentDjcfSn_djclassifields extends JPlugin
{
    public $plgParams = array();

	function __construct(&$subject,$config)
	{
        parent::__construct($subject,$config);

		SNGlobal::loadLanguage('plg_djclassifiedspayment_djcfsn_djclassifields',JPATH_ADMINISTRATOR);

        $params = array();
		$params["plugin_name"] = "djcfsn_djclassifields";
		$params["logo"] = "sn-logo.png";
		$params["sn_portal_title"] = $this->params->get('sn_portal_title','پرداخت آنلاین');
		$params["sn_portal_desc"] = $this->params->get('sn_portal_desc','قابل پرداخت با کلیه کارت های عضو شتاب');
        $params["sn_pin"] = $this->params->get('sn_pin','');
        $params["sn_currency"] = $this->params->get('sn_currency','');
        $params["sn_send_payer_info"] = $this->params->get('sn_send_payer_info','');

        $this->plgParams = $params;
	}

	// Display Payment Icon & Buy Button
	function onPaymentMethodList($val)
	{
		$type='';
		if(!empty($val['type']))
		{
			$type = '&type='.$val['type'];	
		}

		$method = $this->plgParams["plugin_name"];

		$paymentLogoPath = JURI::root()."plugins/djclassifiedspayment/".$method."/".$method."/images/".$this->plgParams["logo"];
		$formAction = JRoute::_("index.php?option=com_djclassifieds&task=processPayment&ptype=".$method."&pactiontype=process&id=".$val["id"].$type,false);
		$html = '<table cellpadding="5" cellspacing="0" width="100%" border="0">
			<tr>';
				if($this->plgParams["logo"] != "")
				{
					$html .='<td class="td1" width="160" align="center">
                                <img src="'.$paymentLogoPath.'" title="'. $this->plgParams["sn_portal_title"].'"/>
                             </td>';
				 }
				$html .='<td class="td2">
					<h2>'.$this->plgParams['sn_portal_title'].'</h2>
					<p style="text-align:justify;">'.$this->plgParams["sn_portal_desc"].'</p>
				</td>
				<td class="td3" width="130" align="center">
					<a class="button" style="text-decoration:none;" href="'.$formAction.'">'.JText::_('COM_DJCLASSIFIEDS_BUY_NOW').'</a>
				</td>
			</tr>
		</table>';
		
		return $html;
	}
	
	function onProcessPayment()
	{
		$method = SNGlobal::getVar('ptype');
		$id = SNGlobal::getVar('id');
		$html = '';

		if($method == $this->plgParams["plugin_name"])
		{
			$action = SNGlobal::getVar('pactiontype');
            switch ($action)
            {
                case "process" :
                    $html = $this->process($id);
                break;
                case "notify" :
                    $html = $this->verify();
                break;
                default :
                    $html =  $this->process($id);
                break;
            }
		}
		
		return $html;
	}

	// Request Transaction
	function process($id)
	{
        $app = JFactory::getApplication();
		JTable::addIncludePath( JPATH_COMPONENT_ADMINISTRATOR .DS. 'tables');
		jimport('joomla.database.table');

        $itemId = SNGlobal::getVar('Itemid',0);
        $ptype	= SNGlobal::getVar('ptype');
        $type	= SNGlobal::getVar('type');

        $itemDetails = DJClassifiedsPayment::processPayment($id, $type,$ptype);

        $amount = $basePrice = $itemDetails['amount'];
        $orderId = $itemDetails['item_id'];
        $method = $this->plgParams["plugin_name"];
        $backUrl = JRoute::_(JURI::root().'index.php?option=com_djclassifieds&task=processPayment&ptype='.$method.'&pactiontype=notify&id='.$id.'&orderId='.$orderId.(!empty($itemId) ? '&Itemid='.$itemId : ''));
        $cancelUrl = JRoute::_(JUri::root().'index.php?option=com_djclassifieds&view=payment&id='.$id.(!empty($type) ? '&type='.$type : '').(!empty($itemId) ? '&Itemid='.$itemId : ''));

        if($amount > 0)
        {
            $pin = $this->plgParams["sn_pin"];
            $currency = $this->plgParams["sn_currency"];
            $sendPayerInfo = $this->plgParams["sn_send_payer_info"];

            $amount = SNApi::modifyPrice($amount,$currency);

            $data = array(
                'pin'=> $pin,
                'price'=> $amount,
                'callback'=> $backUrl,
                'order_id'=> $orderId,
                'mobile'=> '',
                'base_price' => $basePrice,
            );

            list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'djclassifields');

            if($status == true)
            {
                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                echo SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
                echo '<h5 class="dj-connect-to-bank" align="center" style="text-align: center;direction: rtl;">'.JText::_('SN_CONNECTING_TO_PORTAL').'</h5>';
                return;
            }
        }

        $msg = $msg;
        $app->redirect($cancelUrl, '<h5>'.$msg.'</h5>', 'error');
	}

	// Verify transaction
	function verify()
	{
        $app = JFactory::getApplication();

		$orderId = SNGlobal::getVar('orderId',0,'int');
        $au = SNGlobal::getVar('au','');
        $sessionData = SNApi::getData();

        $url = JRoute::_('index.php?option=com_djclassifieds&view=useritems');

        $query = "SELECT * FROM `#__djcf_payments` WHERE `id`='".SNGlobal::escape($orderId)."' ";
        $payment = SNGlobal::selectByQuery($query,2);

        if($payment['type'] == 1)
        {
            $url = JRoute::_('index.php?option=com_djclassifieds&view=userpoints');
        }

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'djclassifields');

            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                DJClassifiedsPayment::completePayment($orderId,$sessionData['base_price'],$bankAu);

                $successMsg = '<h5>'.JText::_('SN_PAID_TRANSACTION').'</h5>';
                $successMsg = str_replace('{REF}',$bankAu,$successMsg);
                $app->redirect($url,$successMsg,'message');
                return;
            }
        }

        $errorMsg = '<h5>'.JText::_('SN_UNPAID_TRANSACTION').'</h5>';
        $app->redirect($url,$errorMsg,'error');
	}
}
?>